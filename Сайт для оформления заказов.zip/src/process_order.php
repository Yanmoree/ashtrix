<?php
require_once 'auth_config.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Проверяем метод запроса
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

try {
    // Check if user is authenticated
    $currentUser = getCurrentUser();
    
    // Получаем данные из формы
    $companyName = trim($_POST['companyName'] ?? '');
    $contactPerson = trim($_POST['contactPerson'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $inn = trim($_POST['inn'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $deliveryType = trim($_POST['deliveryType'] ?? 'pickup');
    $comments = trim($_POST['comments'] ?? '');
    $cartData = $_POST['cart_data'] ?? '';
    $total = floatval($_POST['total'] ?? 0);

    // If user is authenticated, pre-fill some data
    if ($currentUser) {
        if (empty($contactPerson)) {
            $contactPerson = $currentUser['name'];
        }
        if (empty($email)) {
            $email = $currentUser['email'];
        }
        if (empty($companyName) && !empty($currentUser['company'])) {
            $companyName = $currentUser['company'];
        }
        if (empty($phone) && !empty($currentUser['phone'])) {
            $phone = $currentUser['phone'];
        }
    }

    // Валидация обязательных полей
    if (empty($companyName) || empty($contactPerson) || empty($phone)) {
        echo json_encode(['success' => false, 'error' => 'Required fields missing']);
        exit;
    }

    // Валидация телефона
    if (!preg_match('/^\+?[0-9\s\-\(\)]{10,}$/', $phone)) {
        echo json_encode(['success' => false, 'error' => 'Invalid phone number']);
        exit;
    }

    // Валидация email если указан
    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'error' => 'Invalid email address']);
        exit;
    }

    // Декодируем данные корзины
    $cart = json_decode($cartData, true);
    if (!$cart || !is_array($cart) || empty($cart)) {
        echo json_encode(['success' => false, 'error' => 'Empty cart']);
        exit;
    }

    // Создаем уникальный ID заказа
    $orderId = 'ORD-' . date('Y') . '-' . sprintf('%06d', rand(1, 999999));
    
    // Подготавливаем данные заказа
    $orderData = [
        'order_id' => $orderId,
        'user_id' => $currentUser ? $currentUser['id'] : null, // Link to user if authenticated
        'company_name' => $companyName,
        'contact_person' => $contactPerson,
        'phone' => $phone,
        'email' => $email,
        'inn' => $inn,
        'address' => $address,
        'delivery_type' => $deliveryType,
        'comments' => $comments,
        'cart' => $cart,
        'total' => $total,
        'order_date' => date('Y-m-d H:i:s'),
        'status' => 'new'
    ];

    // Сохраняем заказ в файл (в реальном проекте используйте базу данных)
    $ordersDir = 'orders';
    if (!is_dir($ordersDir)) {
        mkdir($ordersDir, 0755, true);
    }
    
    $orderFile = $ordersDir . '/' . $orderId . '.json';
    if (file_put_contents($orderFile, json_encode($orderData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) === false) {
        echo json_encode(['success' => false, 'error' => 'Failed to save order']);
        exit;
    }

    // Отправляем email уведомление (опционально)
    $subject = 'Новый заказ № ' . $orderId . ' - А-Штрих';
    $message = "Получен новый заказ:\n\n";
    $message .= "Номер заказа: " . $orderId . "\n";
    $message .= "Организация: " . $companyName . "\n";
    $message .= "Контактное лицо: " . $contactPerson . "\n";
    $message .= "Телефон: " . $phone . "\n";
    $message .= "Email: " . $email . "\n";
    $message .= "ИНН: " . $inn . "\n";
    $message .= "Адрес: " . $address . "\n";
    $message .= "Способ получения: " . ($deliveryType === 'delivery' ? 'Доставка' : 'Самовывоз') . "\n";
    $message .= "Комментарии: " . $comments . "\n\n";
    $message .= "Товары:\n";
    
    foreach ($cart as $item) {
        $message .= "- " . $item['name'] . " x " . $item['quantity'] . " = " . number_format($item['price'] * $item['quantity'], 0, '.', ' ') . " ₽\n";
    }
    
    $message .= "\nОбщая сумма: " . number_format($total, 0, '.', ' ') . " ₽\n";
    $message .= "\nДата заказа: " . date('d.m.Y H:i');

    $headers = "From: noreply@a-shtrih.ru\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

    // Раскомментируйте строку ниже для отправки email
    // mail('orders@a-shtrih.ru', $subject, $message, $headers);

    // Логируем заказ
    $logEntry = date('Y-m-d H:i:s') . " - New order: " . $orderId . " from " . $companyName . " (" . $phone . ")\n";
    file_put_contents('orders.log', $logEntry, FILE_APPEND | LOCK_EX);

    // Возвращаем успешный ответ
    echo json_encode([
        'success' => true,
        'order_id' => $orderId,
        'message' => 'Order created successfully'
    ]);

} catch (Exception $e) {
    error_log('Order processing error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Internal server error']);
}
?>