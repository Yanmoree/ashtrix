<?php
// Простая админ панель для просмотра заказов и заявок
session_start();

// Простая авторизация (в реальном проекте используйте более безопасный метод)
$admin_password = 'admin123'; // Измените пароль!

if (isset($_POST['password'])) {
    if ($_POST['password'] === $admin_password) {
        $_SESSION['admin_logged_in'] = true;
    } else {
        $error = 'Неверный пароль';
    }
}

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: admin.php');
    exit;
}

if (!isset($_SESSION['admin_logged_in'])) {
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Админ панель - А-Штрих</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="page-container">
        <div class="container">
            <div style="max-width: 400px; margin: 0 auto;">
                <div class="card">
                    <div class="card-header">
                        <h2>Вход в админ панель</h2>
                    </div>
                    <div class="card-content">
                        <?php if (isset($error)): ?>
                            <div style="color: var(--color-destructive); margin-bottom: 1rem;"><?php echo $error; ?></div>
                        <?php endif; ?>
                        <form method="POST">
                            <div class="form-group">
                                <label for="password">Пароль:</label>
                                <input type="password" id="password" name="password" required>
                            </div>
                            <button type="submit" class="btn btn-primary btn-full">Войти</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php
    exit;
}

// Функции для работы с данными
function getOrders() {
    $orders = [];
    $ordersDir = 'orders';
    if (is_dir($ordersDir)) {
        $files = glob($ordersDir . '/*.json');
        foreach ($files as $file) {
            $data = json_decode(file_get_contents($file), true);
            if ($data) {
                $orders[] = $data;
            }
        }
    }
    // Сортируем по дате создания (новые сначала)
    usort($orders, function($a, $b) {
        return strtotime($b['order_date']) - strtotime($a['order_date']);
    });
    return $orders;
}

function getSupportTickets() {
    $tickets = [];
    $ticketsDir = 'support_tickets';
    if (is_dir($ticketsDir)) {
        $files = glob($ticketsDir . '/*.json');
        foreach ($files as $file) {
            $data = json_decode(file_get_contents($file), true);
            if ($data) {
                $tickets[] = $data;
            }
        }
    }
    // Сортируем по дате создания (новые сначала)
    usort($tickets, function($a, $b) {
        return strtotime($b['created_date']) - strtotime($a['created_date']);
    });
    return $tickets;
}

$orders = getOrders();
$supportTickets = getSupportTickets();
$activeTab = $_GET['tab'] ?? 'orders';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Админ панель - А-Штрих</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .admin-header {
            background: var(--color-primary);
            color: white;
            padding: 1rem 0;
            margin-bottom: 2rem;
        }
        .admin-nav {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
        }
        .admin-nav a {
            padding: 0.5rem 1rem;
            text-decoration: none;
            color: var(--color-foreground);
            border: 1px solid var(--color-border);
            border-radius: var(--radius);
        }
        .admin-nav a.active {
            background: var(--color-primary);
            color: white;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }
        .stat-card {
            background: var(--color-background);
            padding: 1.5rem;
            border-radius: var(--radius);
            border: 1px solid var(--color-border);
            text-align: center;
        }
        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            color: var(--color-primary);
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: var(--radius);
            overflow: hidden;
            box-shadow: var(--shadow);
        }
        .data-table th,
        .data-table td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid var(--color-border);
        }
        .data-table th {
            background: var(--color-muted);
            font-weight: 600;
        }
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 500;
        }
        .status-new {
            background: #fef3c7;
            color: #92400e;
        }
        .status-in-progress {
            background: #dbeafe;
            color: #1d4ed8;
        }
        .status-completed {
            background: #d1fae5;
            color: #065f46;
        }
        .urgency-critical {
            color: var(--color-destructive);
            font-weight: bold;
        }
        .urgency-high {
            color: #f59e0b;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="admin-header">
        <div class="container">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <h1>Админ панель А-Штрих</h1>
                <a href="?logout=1" class="btn btn-outline-white">Выйти</a>
            </div>
        </div>
    </div>

    <div class="container">
        <!-- Statistics -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?php echo count($orders); ?></div>
                <div>Всего заказов</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo count(array_filter($orders, function($o) { return $o['status'] === 'new'; })); ?></div>
                <div>Новые заказы</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo count($supportTickets); ?></div>
                <div>Заявки в поддержку</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo count(array_filter($supportTickets, function($t) { return $t['urgency'] === 'critical'; })); ?></div>
                <div>Критические заявки</div>
            </div>
        </div>

        <!-- Navigation -->
        <div class="admin-nav">
            <a href="?tab=orders" class="<?php echo $activeTab === 'orders' ? 'active' : ''; ?>">
                <i class="fas fa-shopping-cart"></i> Заказы
            </a>
            <a href="?tab=support" class="<?php echo $activeTab === 'support' ? 'active' : ''; ?>">
                <i class="fas fa-headset"></i> Тех. поддержка
            </a>
        </div>

        <!-- Content -->
        <?php if ($activeTab === 'orders'): ?>
            <div class="card">
                <div class="card-header">
                    <h3>Заказы</h3>
                </div>
                <div class="card-content" style="padding: 0;">
                    <?php if (empty($orders)): ?>
                        <div style="padding: 2rem; text-align: center; color: var(--color-muted-foreground);">
                            Заказов пока нет
                        </div>
                    <?php else: ?>
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Номер заказа</th>
                                    <th>Организация</th>
                                    <th>Контакт</th>
                                    <th>Телефон</th>
                                    <th>Сумма</th>
                                    <th>Дата</th>
                                    <th>Статус</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($orders as $order): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($order['order_id']); ?></strong></td>
                                        <td><?php echo htmlspecialchars($order['company_name']); ?></td>
                                        <td><?php echo htmlspecialchars($order['contact_person']); ?></td>
                                        <td><?php echo htmlspecialchars($order['phone']); ?></td>
                                        <td><strong><?php echo number_format($order['total'], 0, '.', ' '); ?> ₽</strong></td>
                                        <td><?php echo date('d.m.Y H:i', strtotime($order['order_date'])); ?></td>
                                        <td>
                                            <span class="status-badge status-<?php echo $order['status']; ?>">
                                                <?php echo $order['status'] === 'new' ? 'Новый' : $order['status']; ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="7" style="padding-left: 2rem; font-size: 0.875rem; color: var(--color-muted-foreground);">
                                            <strong>Товары:</strong>
                                            <?php foreach ($order['cart'] as $item): ?>
                                                <?php echo htmlspecialchars($item['name']); ?> x<?php echo $item['quantity']; ?> (<?php echo number_format($item['price'], 0, '.', ' '); ?> ₽);
                                            <?php endforeach; ?>
                                            <?php if ($order['comments']): ?>
                                                <br><strong>Комментарий:</strong> <?php echo htmlspecialchars($order['comments']); ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>

        <?php elseif ($activeTab === 'support'): ?>
            <div class="card">
                <div class="card-header">
                    <h3>Заявки в техподдержку</h3>
                </div>
                <div class="card-content" style="padding: 0;">
                    <?php if (empty($supportTickets)): ?>
                        <div style="padding: 2rem; text-align: center; color: var(--color-muted-foreground);">
                            Заявок пока нет
                        </div>
                    <?php else: ?>
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Номер заявки</th>
                                    <th>Имя</th>
                                    <th>Организация</th>
                                    <th>Телефон</th>
                                    <th>Категория</th>
                                    <th>Срочность</th>
                                    <th>Дата</th>
                                    <th>Статус</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($supportTickets as $ticket): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($ticket['ticket_id']); ?></strong></td>
                                        <td><?php echo htmlspecialchars($ticket['name']); ?></td>
                                        <td><?php echo htmlspecialchars($ticket['company'] ?: 'Не указана'); ?></td>
                                        <td><?php echo htmlspecialchars($ticket['phone']); ?></td>
                                        <td><?php echo htmlspecialchars($ticket['category'] ?: 'Не указана'); ?></td>
                                        <td>
                                            <span class="<?php echo $ticket['urgency'] === 'critical' ? 'urgency-critical' : ($ticket['urgency'] === 'high' ? 'urgency-high' : ''); ?>">
                                                <?php 
                                                $urgencyLabels = ['low' => 'Низкая', 'medium' => 'Средняя', 'high' => 'Высокая', 'critical' => 'Критическая'];
                                                echo $urgencyLabels[$ticket['urgency']] ?? 'Средняя';
                                                ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('d.m.Y H:i', strtotime($ticket['created_date'])); ?></td>
                                        <td>
                                            <span class="status-badge status-<?php echo $ticket['status']; ?>">
                                                <?php echo $ticket['status'] === 'new' ? 'Новая' : $ticket['status']; ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="8" style="padding-left: 2rem; font-size: 0.875rem; color: var(--color-muted-foreground);">
                                            <?php if ($ticket['equipment']): ?>
                                                <strong>Оборудование:</strong> <?php echo htmlspecialchars($ticket['equipment']); ?><br>
                                            <?php endif; ?>
                                            <strong>Описание:</strong> <?php echo nl2br(htmlspecialchars($ticket['description'])); ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>