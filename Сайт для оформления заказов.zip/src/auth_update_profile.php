<?php
require_once 'auth_config.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

try {
    // Check if user is authenticated
    $currentUser = getCurrentUser();
    
    if (!$currentUser) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Not authenticated']);
        exit;
    }

    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode(['success' => false, 'error' => 'Invalid JSON data']);
        exit;
    }

    // Extract and sanitize data
    $updateData = [];
    
    if (isset($input['name'])) {
        $updateData['name'] = sanitizeInput($input['name']);
    }
    
    if (isset($input['company'])) {
        $updateData['company'] = sanitizeInput($input['company']);
    }
    
    if (isset($input['phone'])) {
        $updateData['phone'] = sanitizeInput($input['phone']);
    }
    
    if (isset($input['email'])) {
        $email = sanitizeInput($input['email']);
        if (!validateEmail($email)) {
            echo json_encode(['success' => false, 'error' => 'Некорректный email адрес']);
            exit;
        }
        
        // Check if email is already taken by another user
        $existingUser = getUserByEmail($email);
        if ($existingUser && $existingUser['user_id'] !== $currentUser['id']) {
            echo json_encode(['success' => false, 'error' => 'Email уже используется другим пользователем']);
            exit;
        }
        
        $updateData['email'] = $email;
    }

    // Validation
    if (isset($updateData['name']) && empty($updateData['name'])) {
        echo json_encode(['success' => false, 'error' => 'Имя не может быть пустым']);
        exit;
    }

    if (empty($updateData)) {
        echo json_encode(['success' => false, 'error' => 'Нет данных для обновления']);
        exit;
    }

    // Update user
    $success = updateUser($currentUser['id'], $updateData);
    
    if (!$success) {
        echo json_encode(['success' => false, 'error' => 'Ошибка обновления профиля']);
        exit;
    }

    // If email was updated, update the email lookup file
    if (isset($updateData['email']) && $updateData['email'] !== $currentUser['email']) {
        // Remove old email lookup
        $oldEmailFile = USERS_DIR . '/' . md5($currentUser['email']) . '.json';
        if (file_exists($oldEmailFile)) {
            unlink($oldEmailFile);
        }
        
        // Create new email lookup
        $newEmailFile = USERS_DIR . '/' . md5($updateData['email']) . '.json';
        file_put_contents($newEmailFile, json_encode(['user_id' => $currentUser['id']], JSON_PRETTY_PRINT));
        
        // Update session email
        $_SESSION['user_email'] = $updateData['email'];
    }

    // Log activity
    logActivity('Profile updated', json_encode($updateData));

    echo json_encode([
        'success' => true,
        'message' => 'Профиль успешно обновлен'
    ]);

} catch (Exception $e) {
    error_log('Profile update error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Внутренняя ошибка сервера']);
}
?>