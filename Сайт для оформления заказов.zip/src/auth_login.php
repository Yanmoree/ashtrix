<?php
require_once 'auth_config.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

try {
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode(['success' => false, 'error' => 'Invalid JSON data']);
        exit;
    }

    // Extract and sanitize data
    $email = sanitizeInput($input['email'] ?? '');
    $password = $input['password'] ?? '';

    // Validation
    if (empty($email) || empty($password)) {
        echo json_encode(['success' => false, 'error' => 'Заполните все поля']);
        exit;
    }

    if (!validateEmail($email)) {
        echo json_encode(['success' => false, 'error' => 'Некорректный email адрес']);
        exit;
    }

    // Find user by email
    $user = getUserByEmail($email);
    
    if (!$user) {
        // Log failed attempt
        logActivity('Failed login attempt', $email . ' - user not found');
        echo json_encode(['success' => false, 'error' => 'Неверный email или пароль']);
        exit;
    }

    // Get full user data
    $fullUser = getUserById($user['user_id']);
    
    if (!$fullUser) {
        echo json_encode(['success' => false, 'error' => 'Ошибка загрузки данных пользователя']);
        exit;
    }

    // Verify password
    if (!verifyPassword($password, $fullUser['password_hash'])) {
        // Log failed attempt
        logActivity('Failed login attempt', $email . ' - wrong password');
        echo json_encode(['success' => false, 'error' => 'Неверный email или пароль']);
        exit;
    }

    // Login the user
    loginUser($fullUser);

    // Log successful login
    logActivity('User login', $email);

    // Return user data (without password hash)
    $userData = [
        'id' => $fullUser['id'],
        'email' => $fullUser['email'],
        'name' => $fullUser['name'],
        'company' => $fullUser['company'],
        'phone' => $fullUser['phone'],
        'role' => $fullUser['role'],
        'registrationDate' => $fullUser['registration_date']
    ];

    echo json_encode([
        'success' => true,
        'user' => $userData,
        'message' => 'Вход выполнен успешно'
    ]);

} catch (Exception $e) {
    error_log('Login error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Внутренняя ошибка сервера']);
}
?>