<?php
// Database configuration (для будущего подключения к БД)
const DB_CONFIG = [
    'host' => 'localhost',
    'dbname' => 'a_shtrih',
    'username' => 'your_username',
    'password' => 'your_password'
];

// Session configuration
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1);
ini_set('session.use_strict_mode', 1);

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// File-based storage directories (временное решение до подключения БД)
const USERS_DIR = 'users';
const SESSIONS_DIR = 'sessions';

// Create directories if they don't exist
if (!is_dir(USERS_DIR)) {
    mkdir(USERS_DIR, 0755, true);
}
if (!is_dir(SESSIONS_DIR)) {
    mkdir(SESSIONS_DIR, 0755, true);
}

// Helper functions for file-based user management
function getUserByEmail($email) {
    $userFile = USERS_DIR . '/' . md5($email) . '.json';
    if (file_exists($userFile)) {
        return json_decode(file_get_contents($userFile), true);
    }
    return null;
}

function getUserById($id) {
    $userFile = USERS_DIR . '/' . $id . '.json';
    if (file_exists($userFile)) {
        return json_decode(file_get_contents($userFile), true);
    }
    return null;
}

function saveUser($user) {
    $userFile = USERS_DIR . '/' . $user['id'] . '.json';
    return file_put_contents($userFile, json_encode($user, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) !== false;
}

function createUser($email, $password, $name, $company = '', $phone = '') {
    // Check if user already exists
    if (getUserByEmail($email)) {
        return false;
    }

    $userId = 'user_' . uniqid();
    $user = [
        'id' => $userId,
        'email' => $email,
        'password_hash' => password_hash($password, PASSWORD_DEFAULT),
        'name' => $name,
        'company' => $company,
        'phone' => $phone,
        'role' => 'user',
        'registration_date' => date('Y-m-d H:i:s'),
        'created_at' => time()
    ];

    // Save user with email as key for easy lookup
    $emailKeyFile = USERS_DIR . '/' . md5($email) . '.json';
    file_put_contents($emailKeyFile, json_encode(['user_id' => $userId], JSON_PRETTY_PRINT));

    return saveUser($user) ? $user : false;
}

function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

function getCurrentUser() {
    if (isset($_SESSION['user_id'])) {
        return getUserById($_SESSION['user_id']);
    }
    return null;
}

function loginUser($user) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['login_time'] = time();
    
    // Save session info
    $sessionFile = SESSIONS_DIR . '/' . session_id() . '.json';
    file_put_contents($sessionFile, json_encode([
        'user_id' => $user['id'],
        'login_time' => time(),
        'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
    ], JSON_PRETTY_PRINT));
}

function logoutUser() {
    // Remove session file
    $sessionFile = SESSIONS_DIR . '/' . session_id() . '.json';
    if (file_exists($sessionFile)) {
        unlink($sessionFile);
    }
    
    // Clear session
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
}

function updateUser($userId, $data) {
    $user = getUserById($userId);
    if (!$user) {
        return false;
    }

    // Update allowed fields
    $allowedFields = ['name', 'company', 'phone', 'email'];
    foreach ($allowedFields as $field) {
        if (isset($data[$field])) {
            $user[$field] = $data[$field];
        }
    }

    $user['updated_at'] = time();
    return saveUser($user);
}

function getUserOrders($userId) {
    $orders = [];
    $ordersDir = 'orders';
    
    if (is_dir($ordersDir)) {
        $files = glob($ordersDir . '/*.json');
        foreach ($files as $file) {
            $orderData = json_decode(file_get_contents($file), true);
            if ($orderData && isset($orderData['user_id']) && $orderData['user_id'] === $userId) {
                $orders[] = $orderData;
            }
        }
    }
    
    // Sort by date (newest first)
    usort($orders, function($a, $b) {
        return strtotime($b['order_date']) - strtotime($a['order_date']);
    });
    
    return $orders;
}

function getUserSupportTickets($userId) {
    $tickets = [];
    $ticketsDir = 'support_tickets';
    
    if (is_dir($ticketsDir)) {
        $files = glob($ticketsDir . '/*.json');
        foreach ($files as $file) {
            $ticketData = json_decode(file_get_contents($file), true);
            if ($ticketData && isset($ticketData['user_id']) && $ticketData['user_id'] === $userId) {
                $tickets[] = $ticketData;
            }
        }
    }
    
    // Sort by date (newest first)
    usort($tickets, function($a, $b) {
        return strtotime($b['created_date']) - strtotime($a['created_date']);
    });
    
    return $tickets;
}

function sanitizeInput($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function logActivity($action, $details = '') {
    $logEntry = date('Y-m-d H:i:s') . " - " . $action;
    if ($details) {
        $logEntry .= " - " . $details;
    }
    if (isset($_SESSION['user_id'])) {
        $logEntry .= " - User: " . $_SESSION['user_id'];
    }
    $logEntry .= " - IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown') . "\n";
    
    file_put_contents('auth.log', $logEntry, FILE_APPEND | LOCK_EX);
}
?>