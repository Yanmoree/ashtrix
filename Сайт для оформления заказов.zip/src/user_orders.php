<?php
require_once 'auth_config.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

try {
    // Check if user is authenticated
    $currentUser = getCurrentUser();
    
    if (!$currentUser) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Not authenticated']);
        exit;
    }

    // Get user's orders
    $orders = getUserOrders($currentUser['id']);
    
    // Format orders for frontend
    $formattedOrders = [];
    foreach ($orders as $order) {
        $formattedOrders[] = [
            'id' => $order['order_id'],
            'orderDate' => $order['order_date'],
            'status' => $order['status'],
            'total' => $order['total'],
            'items' => $order['cart'] ?? []
        ];
    }

    echo json_encode([
        'success' => true,
        'orders' => $formattedOrders
    ]);

} catch (Exception $e) {
    error_log('User orders error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Internal server error']);
}
?>