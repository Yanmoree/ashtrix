// Products data
const products = [
    {
        id: "1",
        name: "АТОЛ 30Ф",
        category: "Фискальные регистраторы",
        price: 25000,
        description: "Компактный фискальный регистратор для малого бизнеса",
        features: ["USB интерфейс", "Скорость печати 250 мм/с", "Автообрезчик", "ФН-1.1"],
        inStock: true,
        image: "https://images.unsplash.com/photo-1586953208448-b95a79798f07?w=300&h=200&fit=crop"
    },
    {
        id: "2",
        name: "АТОЛ 77Ф",
        category: "ККТ",
        price: 45000,
        description: "Универсальная ККТ с сенсорным экраном",
        features: ["Android 7.1", "Сенсорный экран 7\"", "Wi-Fi, Ethernet", "2D сканер"],
        inStock: true,
        image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=300&h=200&fit=crop"
    },
    {
        id: "3",
        name: "Меркурий 115Ф",
        category: "ККТ",
        price: 32000,
        description: "Надежная ККТ для розничной торговли",
        features: ["Клавиатура", "LCD дисплей", "RS-232, USB", "ФН-1.1"],
        inStock: false,
        image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=300&h=200&fit=crop"
    },
    {
        id: "4",
        name: "ШТРИХ-ПРИНТ-01Ф",
        category: "Фискальные регистраторы",
        price: 28000,
        description: "Профессиональный фискальный регистратор",
        features: ["Ethernet", "Скорость печати 300 мм/с", "Автообрезчик", "Выносной дисплей"],
        inStock: true,
        image: "https://images.unsplash.com/photo-1612198188060-c7c2a3b66eae?w=300&h=200&fit=crop"
    },
    {
        id: "5",
        name: "2D сканер Honeywell",
        category: "Сканеры",
        price: 12000,
        description: "Беспроводной 2D сканер штрих-кодов",
        features: ["2D сканирование", "Беспроводной", "Дальность до 100м", "Защита IP42"],
        inStock: true,
        image: "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=300&h=200&fit=crop"
    },
    {
        id: "6",
        name: "Денежный ящик EC-410",
        category: "Денежные ящики",
        price: 8500,
        description: "Металлический денежный ящик с электронным замком",
        features: ["Металлический корпус", "5 отделений для купюр", "8 отделений для монет", "Электронный замок"],
        inStock: true,
        image: "https://images.unsplash.com/photo-1553729459-efe14ef6055d?w=300&h=200&fit=crop"
    }
];

// Cart management
let cart = JSON.parse(localStorage.getItem('cart')) || [];

function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
}

function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (!product || !product.inStock) return;

    const existingItem = cart.find(item => item.id === productId);
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            id: product.id,
            name: product.name,
            price: product.price,
            quantity: 1,
            image: product.image
        });
    }
    
    saveCart();
    updateCartCount();
    showToast(`${product.name} добавлен в корзину`);
}

function updateQuantity(productId, quantity) {
    const item = cart.find(item => item.id === productId);
    if (item) {
        item.quantity = Math.max(1, quantity);
        saveCart();
        updateCartCount();
        loadCartPage(); // Refresh cart page if we're on it
    }
}

function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    saveCart();
    updateCartCount();
    loadCartPage(); // Refresh cart page if we're on it
    showToast("Товар удален из корзины");
}

function updateCartCount() {
    const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
    const cartCountElements = document.querySelectorAll('#cartCount');
    cartCountElements.forEach(element => {
        element.textContent = cartCount;
        if (cartCount > 0) {
            element.classList.remove('hidden');
        } else {
            element.classList.add('hidden');
        }
    });
}

function getCartTotal() {
    return cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
}

// Product catalog functions
function loadProducts() {
    const grid = document.getElementById('productsGrid');
    if (!grid) return;

    renderProducts(products);
}

function renderProducts(productsToRender) {
    const grid = document.getElementById('productsGrid');
    const noResults = document.getElementById('noResults');
    
    if (productsToRender.length === 0) {
        grid.innerHTML = '';
        noResults.style.display = 'block';
        return;
    }

    noResults.style.display = 'none';
    
    grid.innerHTML = productsToRender.map(product => `
        <div class="product-card">
            <div class="product-image">
                <img src="${product.image}" alt="${product.name}">
            </div>
            <div class="product-content">
                <div class="product-category">${product.category}</div>
                <h3>${product.name}</h3>
                <p>${product.description}</p>
                <ul class="features-list">
                    ${product.features.map(feature => `<li>${feature}</li>`).join('')}
                </ul>
                <div class="product-footer">
                    <div>
                        <div class="price">${product.price.toLocaleString('ru-RU')} ₽</div>
                        <div class="${product.inStock ? 'in-stock' : 'out-of-stock'}">
                            ${product.inStock ? 'В наличии' : 'Под заказ'}
                        </div>
                    </div>
                    <button 
                        class="btn btn-primary btn-sm" 
                        onclick="addToCart('${product.id}')"
                        ${!product.inStock ? 'disabled' : ''}
                    >
                        <i class="fas fa-shopping-cart"></i>
                        В корзину
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

function setupFilters() {
    const searchInput = document.getElementById('searchInput');
    const categoryFilter = document.getElementById('categoryFilter');
    
    if (!searchInput || !categoryFilter) return;

    function filterProducts() {
        const searchTerm = searchInput.value.toLowerCase();
        const selectedCategory = categoryFilter.value;
        
        const filtered = products.filter(product => {
            const matchesSearch = product.name.toLowerCase().includes(searchTerm) ||
                                product.description.toLowerCase().includes(searchTerm);
            const matchesCategory = !selectedCategory || product.category === selectedCategory;
            return matchesSearch && matchesCategory;
        });
        
        renderProducts(filtered);
    }

    searchInput.addEventListener('input', filterProducts);
    categoryFilter.addEventListener('change', filterProducts);
}

// Cart page functions
function loadCartPage() {
    const cartContent = document.getElementById('cartContent');
    const emptyCart = document.getElementById('emptyCart');
    
    if (!cartContent || !emptyCart) return;

    if (cart.length === 0) {
        cartContent.style.display = 'none';
        emptyCart.style.display = 'block';
        return;
    }

    emptyCart.style.display = 'none';
    cartContent.style.display = 'grid';
    
    const total = getCartTotal();
    
    cartContent.innerHTML = `
        <div class="cart-items-section">
            <div class="card">
                <div class="card-header">
                    <h3>Товары в корзине</h3>
                </div>
                <div class="card-content">
                    <div class="cart-items">
                        ${cart.map(item => `
                            <div class="cart-item">
                                <div class="cart-item-image">
                                    <img src="${item.image}" alt="${item.name}">
                                </div>
                                <div class="cart-item-info">
                                    <h4>${item.name}</h4>
                                    <p>${item.price.toLocaleString('ru-RU')} ₽</p>
                                </div>
                                <div class="cart-item-controls">
                                    <button class="quantity-btn" onclick="updateQuantity('${item.id}', ${item.quantity - 1})">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                    <span class="quantity">${item.quantity}</span>
                                    <button class="quantity-btn" onclick="updateQuantity('${item.id}', ${item.quantity + 1})">
                                        <i class="fas fa-plus"></i>
                                    </button>
                                    <button class="remove-btn" onclick="removeFromCart('${item.id}')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                    <div class="cart-total">
                        <div class="total-row">
                            <span>Итого:</span>
                            <span class="total-amount">${total.toLocaleString('ru-RU')} ₽</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="order-form-section">
            <div class="card">
                <div class="card-header">
                    <h3>Данные заказчика</h3>
                    <p>Заполните информацию для оформления заказа</p>
                </div>
                <div class="card-content">
                    <form id="orderForm" method="POST" action="process_order.php">
                        <div class="form-group">
                            <label for="companyName">Название организации *</label>
                            <input type="text" id="companyName" name="companyName" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="contactPerson">Контактное лицо *</label>
                            <input type="text" id="contactPerson" name="contactPerson" required>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="phone">Телефон *</label>
                                <input type="tel" id="phone" name="phone" required>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" id="email" name="email">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="inn">ИНН</label>
                            <input type="text" id="inn" name="inn">
                        </div>
                        
                        <div class="form-group">
                            <label for="address">Адрес доставки</label>
                            <textarea id="address" name="address" placeholder="Укажите полный адрес доставки"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="deliveryType">Способ получения</label>
                            <select id="deliveryType" name="deliveryType">
                                <option value="pickup">Самовывоз</option>
                                <option value="delivery">Доставка</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="comments">Комментарии к заказу</label>
                            <textarea id="comments" name="comments" placeholder="Дополнительные пожелания, сроки поставки..."></textarea>
                        </div>
                        
                        <input type="hidden" name="cart_data" value='${JSON.stringify(cart)}'>
                        <input type="hidden" name="total" value="${total}">
                        
                        <button type="submit" class="btn btn-primary btn-full">Оформить заказ</button>
                    </form>
                </div>
            </div>
        </div>
    `;
    
    setupOrderForm();
}

function setupOrderForm() {
    const form = document.getElementById('orderForm');
    if (!form) return;
    
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const companyName = document.getElementById('companyName').value;
        const contactPerson = document.getElementById('contactPerson').value;
        const phone = document.getElementById('phone').value;
        
        if (!companyName || !contactPerson || !phone) {
            alert('Пожалуйста, заполните обязательные поля');
            return;
        }
        
        // Submit form via AJAX
        const formData = new FormData(form);
        
        fetch('process_order.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                cart = [];
                saveCart();
                updateCartCount();
                showModal('successModal');
            } else {
                alert('Ошибка при оформлении заказа. Попробуйте еще раз.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Ошибка при оформлении заказа. Попробуйте еще раз.');
        });
    });
}

// Support page functions
function setupSupportForm() {
    const form = document.getElementById('supportForm');
    if (!form) return;
    
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const name = document.getElementById('name').value;
        const phone = document.getElementById('phone').value;
        const description = document.getElementById('description').value;
        
        if (!name || !phone || !description) {
            alert('Пожалуйста, заполните обязательные поля');
            return;
        }
        
        // Submit form via AJAX
        const formData = new FormData(form);
        
        fetch('process_support.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                form.reset();
                showModal('successModal');
            } else {
                alert('Ошибка при отправке заявки. Попробуйте еще раз.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Ошибка при отправке заявки. Попробуйте еще раз.');
        });
    });
}

// FAQ toggle
function toggleFaq(element) {
    const answer = element.nextElementSibling;
    const isActive = element.classList.contains('active');
    
    // Close all FAQ items
    document.querySelectorAll('.faq-question').forEach(q => {
        q.classList.remove('active');
        q.nextElementSibling.classList.remove('show');
    });
    
    // Open clicked item if it wasn't active
    if (!isActive) {
        element.classList.add('active');
        answer.classList.add('show');
    }
}

// Modal functions
function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('show');
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('show');
    }
}

// Toast notifications
function showToast(message) {
    const toast = document.getElementById('toast');
    const toastMessage = document.getElementById('toastMessage');
    
    if (toast && toastMessage) {
        toastMessage.textContent = message;
        toast.classList.add('show');
        
        setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    updateCartCount();
    
    // Close modals when clicking outside
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal')) {
            e.target.classList.remove('show');
        }
    });
});