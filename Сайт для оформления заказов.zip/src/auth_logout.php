<?php
require_once 'auth_config.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

try {
    $user = getCurrentUser();
    
    if ($user) {
        // Log logout
        logActivity('User logout', $user['email']);
        
        // Logout user
        logoutUser();
        
        echo json_encode([
            'success' => true,
            'message' => 'Выход выполнен успешно'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'error' => 'User not authenticated'
        ]);
    }

} catch (Exception $e) {
    error_log('Logout error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Internal server error']);
}
?>