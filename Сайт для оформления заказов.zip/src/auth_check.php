<?php
require_once 'auth_config.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

try {
    $user = getCurrentUser();
    
    if ($user) {
        // Return user data (without password hash)
        $userData = [
            'id' => $user['id'],
            'email' => $user['email'],
            'name' => $user['name'],
            'company' => $user['company'],
            'phone' => $user['phone'],
            'role' => $user['role'],
            'registrationDate' => $user['registration_date']
        ];

        echo json_encode([
            'success' => true,
            'user' => $userData
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'error' => 'Not authenticated'
        ]);
    }

} catch (Exception $e) {
    error_log('Auth check error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Internal server error']);
}
?>