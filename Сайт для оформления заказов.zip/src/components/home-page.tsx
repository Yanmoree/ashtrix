import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Star, CheckCircle, Users, Clock, Shield, Phone, MapPin, Mail } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface HomePageProps {
  onNavigateToSection: (section: string) => void;
}

export function HomePage({ onNavigateToSection }: HomePageProps) {
  const benefits = [
    {
      icon: Shield,
      title: "Надежность",
      description: "15 лет на рынке кассового оборудования. Официальный дилер ведущих производителей."
    },
    {
      icon: Users,
      title: "Экспертность", 
      description: "Команда сертифицированных специалистов поможет выбрать оптимальное решение."
    },
    {
      icon: Clock,
      title: "Быстрый сервис",
      description: "Техническая поддержка 24/7. Выездное обслуживание в день обращения."
    },
    {
      icon: CheckCircle,
      title: "Полный цикл",
      description: "От консультации до установки и обслуживания. Помощь в регистрации ККТ."
    }
  ];

  const popularProducts = [
    {
      name: "АТОЛ 30Ф",
      category: "Фискальный регистратор",
      price: "от 25 000 ₽",
      description: "Компактное решение для малого бизнеса",
      image: "https://images.unsplash.com/photo-1586953208448-b95a79798f07?w=300&h=200&fit=crop"
    },
    {
      name: "АТОЛ 77Ф",
      category: "ККТ с эквайрингом",
      price: "от 45 000 ₽", 
      description: "Универсальная касса с сенсорным экраном",
      image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=300&h=200&fit=crop"
    },
    {
      name: "Сканер 2D",
      category: "Дополнительное оборудование",
      price: "от 12 000 ₽",
      description: "Беспроводной сканер штрих-кодов",
      image: "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=300&h=200&fit=crop"
    }
  ];

  const testimonials = [
    {
      name: "Анна Петрова",
      company: "ООО «Продукты 24»",
      text: "Отличный сервис! Помогли выбрать и настроить кассу. Работает без сбоев уже полгода.",
      rating: 5
    },
    {
      name: "Михаил Сидоров", 
      company: "ИП Сидоров М.И.",
      text: "Быстро решили проблему с фискальным накопителем. Приехали в тот же день.",
      rating: 5
    },
    {
      name: "Елена Волкова",
      company: "Кафе «Уют»",
      text: "Профессиональная команда. Установили и обучили персонал работе с кассой.",
      rating: 5
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary/5 to-primary/10 py-20">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <Badge variant="outline" className="w-fit">
                  15 лет на рынке
                </Badge>
                <h1 className="text-4xl lg:text-5xl leading-tight">
                  Кассовое оборудование
                  <span className="text-primary block">для вашего бизнеса</span>
                </h1>
                <p className="text-xl text-muted-foreground">
                  Полный спектр услуг: от продажи до обслуживания ККТ. 
                  Официальный дилер АТОЛ, Штрих-М, Меркурий.
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  className="text-lg px-8"
                  onClick={() => onNavigateToSection("catalog")}
                >
                  Смотреть каталог
                </Button>
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="text-lg px-8"
                  onClick={() => onNavigateToSection("support")}
                >
                  Получить консультацию
                </Button>
              </div>

              <div className="flex items-center space-x-8 text-sm text-muted-foreground">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  <span>Гарантия качества</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  <span>Быстрая доставка</span>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="aspect-[4/3] rounded-2xl overflow-hidden bg-muted">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1606857521015-7f9fcf423740?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvZmZpY2UlMjBidXNpbmVzcyUyMHRlY2hub2xvZ3l8ZW58MXx8fHwxNzU4MjgxODE5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Современное кассовое оборудование"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-background">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="mb-4">Почему выбирают А-Штрих</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Мы предлагаем комплексные решения для автоматизации торговли и услуг
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <Card key={index} className="text-center border-0 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="pt-8 pb-6">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <benefit.icon className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="mb-2">{benefit.title}</h3>
                  <p className="text-sm text-muted-foreground">
                    {benefit.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Popular Products Section */}
      <section className="py-20 bg-muted/30">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="mb-2">Популярные товары</h2>
              <p className="text-muted-foreground">
                Проверенные решения для разных типов бизнеса
              </p>
            </div>
            <Button 
              variant="outline"
              onClick={() => onNavigateToSection("catalog")}
            >
              Весь каталог
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {popularProducts.map((product, index) => (
              <Card key={index} className="overflow-hidden">
                <div className="aspect-video">
                  <ImageWithFallback
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardContent className="p-6">
                  <Badge variant="secondary" className="mb-3">
                    {product.category}
                  </Badge>
                  <h3 className="mb-2">{product.name}</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    {product.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-semibold">{product.price}</span>
                    <Button 
                      size="sm"
                      onClick={() => onNavigateToSection("catalog")}
                    >
                      Подробнее
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-background">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="mb-4">Отзывы клиентов</h2>
            <p className="text-xl text-muted-foreground">
              Более 1000 довольных клиентов выбрали наши решения
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="border-0 shadow-sm">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-sm text-muted-foreground mb-4 italic">
                    "{testimonial.text}"
                  </p>
                  <div>
                    <p className="font-medium">{testimonial.name}</p>
                    <p className="text-sm text-muted-foreground">{testimonial.company}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="mb-4 text-white">Готовы автоматизировать свой бизнес?</h2>
          <p className="text-xl mb-8 text-primary-foreground/80">
            Получите бесплатную консультацию и подберем оптимальное решение для вашего бизнеса
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              variant="secondary" 
              size="lg" 
              className="text-lg px-8"
              onClick={() => onNavigateToSection("support")}
            >
              Получить консультацию
            </Button>
            <Button 
              variant="outline" 
              size="lg" 
              className="text-lg px-8 border-white text-white hover:bg-white hover:text-primary"
              onClick={() => onNavigateToSection("catalog")}
            >
              Смотреть каталог
            </Button>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-muted/30">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h2 className="mb-6">Контакты и адрес</h2>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <MapPin className="w-6 h-6 text-primary mt-1" />
                  <div>
                    <p className="font-medium">Наш офис</p>
                    <p className="text-muted-foreground">
                      г. Москва, ул. Примерная, д. 123, офис 45
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Пн-Пт: 9:00 - 18:00, Сб: 10:00 - 16:00
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <Phone className="w-6 h-6 text-primary mt-1" />
                  <div>
                    <p className="font-medium">Телефоны</p>
                    <p className="text-muted-foreground">+7 (495) 123-45-67</p>
                    <p className="text-muted-foreground">+7 (800) 555-00-99</p>
                    <p className="text-sm text-muted-foreground">
                      Техподдержка 24/7
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <Mail className="w-6 h-6 text-primary mt-1" />
                  <div>
                    <p className="font-medium">Email</p>
                    <p className="text-muted-foreground">info@a-shtrih.ru</p>
                    <p className="text-muted-foreground">support@a-shtrih.ru</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="aspect-[4/3] rounded-lg overflow-hidden bg-muted">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1576354998198-99dc1d2c3d36?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjByZXRhaWwlMjBzdG9yZXxlbnwxfHx8fDE3NTgyMDI1MzJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Наш офис"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}