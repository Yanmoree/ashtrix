import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Badge } from "./ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "./ui/accordion";
import { Phone, Mail, MessageCircle, FileText, Wrench, HelpCircle } from "lucide-react";

export function TechSupport() {
  const [supportRequest, setSupportRequest] = useState({
    name: "",
    company: "",
    phone: "",
    email: "",
    category: "",
    equipment: "",
    description: "",
    urgency: "medium"
  });

  const handleInputChange = (field: string, value: string) => {
    setSupportRequest(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmitRequest = () => {
    if (!supportRequest.name || !supportRequest.phone || !supportRequest.description) {
      alert("Пожалуйста, заполните обязательные поля");
      return;
    }

    // Here we would normally send to backend
    alert("Заявка отправлена! Мы свяжемся с вами в ближайшее время.");
    
    // Reset form
    setSupportRequest({
      name: "",
      company: "",
      phone: "",
      email: "",
      category: "",
      equipment: "",
      description: "",
      urgency: "medium"
    });
  };

  const faqItems = [
    {
      question: "Как зарегистрировать ККТ в налоговой?",
      answer: "Для регистрации ККТ необходимо подать заявление в налоговую службу с приложением документов. Мы поможем вам с подготовкой всех необходимых документов и сопроводим процесс регистрации."
    },
    {
      question: "Что делать, если ККТ не печатает чеки?",
      answer: "Проверьте наличие термобумаги, правильность установки рулона, состояние печатающей головки. Если проблема не решается, обратитесь в службу технической поддержки."
    },
    {
      question: "Как заменить фискальный накопитель?",
      answer: "Замена ФН должна производиться только авторизованным сервисным центром. Мы предоставляем услуги по замене ФН с выездом к клиенту."
    },
    {
      question: "Какие документы нужны для покупки ККТ?",
      answer: "Для юридических лиц: карточка организации, доверенность (при необходимости). Для ИП: копия свидетельства о регистрации ИП, паспорт."
    }
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="mb-2">Техническая поддержка</h1>
        <p className="text-muted-foreground">
          Профессиональная помощь по настройке, обслуживанию и ремонту кассового оборудования
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Contact Methods */}
        <div className="lg:col-span-1 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Phone className="w-5 h-5" />
                <span>Контакты</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Горячая линия</p>
                    <p className="text-sm text-muted-foreground">+7 (495) 123-45-67</p>
                    <p className="text-xs text-muted-foreground">24/7 для экстренных случаев</p>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Mail className="w-4 h-4 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Email поддержка</p>
                    <p className="text-sm text-muted-foreground">support@a-shtrih.ru</p>
                    <p className="text-xs text-muted-foreground">Ответ в течение 2 часов</p>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <MessageCircle className="w-4 h-4 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Онлайн чат</p>
                    <p className="text-xs text-muted-foreground">Пн-Пт: 9:00 - 18:00</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Wrench className="w-5 h-5" />
                <span>Услуги</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm">Выездное обслуживание</span>
                <Badge variant="outline">Доступно</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Удаленная диагностика</span>
                <Badge variant="outline">24/7</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Замена ФН</span>
                <Badge variant="outline">В день обращения</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Настройка ПО</span>
                <Badge variant="outline">Бесплатно</Badge>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Support Request Form */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Подать заявку в техподдержку</CardTitle>
              <CardDescription>
                Опишите вашу проблему, и мы поможем ее решить
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Ваше имя *</Label>
                  <Input
                    id="name"
                    value={supportRequest.name}
                    onChange={(e) => handleInputChange("name", e.target.value)}
                    placeholder="Иванов Иван"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="company">Организация</Label>
                  <Input
                    id="company"
                    value={supportRequest.company}
                    onChange={(e) => handleInputChange("company", e.target.value)}
                    placeholder="ООО «Ваша компания»"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="phone">Телефон *</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={supportRequest.phone}
                    onChange={(e) => handleInputChange("phone", e.target.value)}
                    placeholder="+7 (999) 123-45-67"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={supportRequest.email}
                    onChange={(e) => handleInputChange("email", e.target.value)}
                    placeholder="email@company.ru"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="category">Категория проблемы</Label>
                  <Select
                    value={supportRequest.category}
                    onValueChange={(value) => handleInputChange("category", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Выберите категорию" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hardware">Аппаратная проблема</SelectItem>
                      <SelectItem value="software">Программная проблема</SelectItem>
                      <SelectItem value="fiscal">Фискальные вопросы</SelectItem>
                      <SelectItem value="setup">Настройка и установка</SelectItem>
                      <SelectItem value="training">Обучение персонала</SelectItem>
                      <SelectItem value="other">Другое</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="urgency">Срочность</Label>
                  <Select
                    value={supportRequest.urgency}
                    onValueChange={(value) => handleInputChange("urgency", value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Низкая</SelectItem>
                      <SelectItem value="medium">Средняя</SelectItem>
                      <SelectItem value="high">Высокая</SelectItem>
                      <SelectItem value="critical">Критическая</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="equipment">Модель оборудования</Label>
                <Input
                  id="equipment"
                  value={supportRequest.equipment}
                  onChange={(e) => handleInputChange("equipment", e.target.value)}
                  placeholder="АТОЛ 30Ф, Меркурий 115Ф..."
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Описание проблемы *</Label>
                <Textarea
                  id="description"
                  value={supportRequest.description}
                  onChange={(e) => handleInputChange("description", e.target.value)}
                  placeholder="Подробно опишите проблему, текст ошибки, что именно не работает..."
                  rows={4}
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSubmitRequest} className="w-full" size="lg">
                Отправить заявку
              </Button>
            </CardFooter>
          </Card>

          {/* FAQ Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <HelpCircle className="w-5 h-5" />
                <span>Часто задаваемые вопросы</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                {faqItems.map((item, index) => (
                  <AccordionItem key={index} value={`item-${index}`}>
                    <AccordionTrigger className="text-left">
                      {item.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground">
                      {item.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}