import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Input } from "./ui/input";
import { Search, ShoppingCart } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  description: string;
  features: string[];
  inStock: boolean;
  image: string;
}

interface ProductCatalogProps {
  onAddToCart: (product: Product) => void;
}

const products: Product[] = [
  {
    id: "1",
    name: "АТОЛ 30Ф",
    category: "Фискальные регистраторы",
    price: 25000,
    description: "Компактный фискальный регистратор для малого бизнеса",
    features: ["USB интерфейс", "Скорость печати 250 мм/с", "Автообрезчик", "ФН-1.1"],
    inStock: true,
    image: "https://images.unsplash.com/photo-1586953208448-b95a79798f07?w=300&h=200&fit=crop"
  },
  {
    id: "2",
    name: "АТОЛ 77Ф",
    category: "ККТ",
    price: 45000,
    description: "Универсальная ККТ с сенсорным экраном",
    features: ["Android 7.1", "Сенсорный экран 7\"", "Wi-Fi, Ethernet", "2D сканер"],
    inStock: true,
    image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=300&h=200&fit=crop"
  },
  {
    id: "3",
    name: "Меркурий 115Ф",
    category: "ККТ",
    price: 32000,
    description: "Надежная ККТ для розничной торговли",
    features: ["Клавиатура", "LCD дисплей", "RS-232, USB", "ФН-1.1"],
    inStock: false,
    image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=300&h=200&fit=crop"
  },
  {
    id: "4",
    name: "ШТРИХ-ПРИНТ-01Ф",
    category: "Фискальные регистраторы",
    price: 28000,
    description: "Профессиональный фискальный регистратор",
    features: ["Ethernet", "Скорость печати 300 мм/с", "Автообрезчик", "Выносной дисплей"],
    inStock: true,
    image: "https://images.unsplash.com/photo-1612198188060-c7c2a3b66eae?w=300&h=200&fit=crop"
  },
  {
    id: "5",
    name: "2D сканер Honeywell",
    category: "Сканеры",
    price: 12000,
    description: "Беспроводной 2D сканер штрих-кодов",
    features: ["2D сканирование", "Беспроводной", "Дальность до 100м", "Защита IP42"],
    inStock: true,
    image: "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=300&h=200&fit=crop"
  },
  {
    id: "6",
    name: "Денежный ящик EC-410",
    category: "Денежные ящики",
    price: 8500,
    description: "Металлический денежный ящик с электронным замком",
    features: ["Металлический корпус", "5 отделений для купюр", "8 отделений для монет", "Электронный замок"],
    inStock: true,
    image: "https://images.unsplash.com/photo-1553729459-efe14ef6055d?w=300&h=200&fit=crop"
  }
];

const categories = ["Все", "ККТ", "Фискальные регистраторы", "Сканеры", "Денежные ящики"];

export function ProductCatalog({ onAddToCart }: ProductCatalogProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("Все");

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "Все" || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="mb-2">Каталог кассового оборудования</h1>
        <p className="text-muted-foreground mb-6">
          Широкий выбор кассовых аппаратов, фискальных регистраторов и дополнительного оборудования
        </p>
        
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Поиск по названию или описанию..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-full md:w-[250px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {categories.map(category => (
                <SelectItem key={category} value={category}>
                  {category}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProducts.map(product => (
          <Card key={product.id} className="flex flex-col">
            <CardHeader className="pb-4">
              <div className="aspect-video relative rounded-lg overflow-hidden bg-muted mb-4">
                <ImageWithFallback
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-lg">{product.name}</CardTitle>
                  <CardDescription>{product.category}</CardDescription>
                </div>
                <Badge variant={product.inStock ? "default" : "secondary"}>
                  {product.inStock ? "В наличии" : "Под заказ"}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="flex-1">
              <p className="text-sm text-muted-foreground mb-4">{product.description}</p>
              <div className="space-y-2">
                <p className="text-sm">Особенности:</p>
                <ul className="text-sm text-muted-foreground space-y-1">
                  {product.features.map((feature, index) => (
                    <li key={index} className="flex items-center">
                      <span className="w-1.5 h-1.5 bg-primary rounded-full mr-2 flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            </CardContent>
            <CardFooter className="flex items-center justify-between pt-4">
              <div>
                <p className="text-2xl font-bold">{product.price.toLocaleString('ru-RU')} ₽</p>
              </div>
              <Button 
                onClick={() => onAddToCart(product)}
                disabled={!product.inStock}
                className="flex items-center space-x-2"
              >
                <ShoppingCart className="w-4 h-4" />
                <span>В корзину</span>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      {filteredProducts.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground">Товары не найдены</p>
        </div>
      )}
    </div>
  );
}