import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Separator } from "./ui/separator";
import { Badge } from "./ui/badge";
import { Trash2, Plus, Minus } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
}

interface ShoppingCartProps {
  cartItems: CartItem[];
  onUpdateQuantity: (id: string, quantity: number) => void;
  onRemoveItem: (id: string) => void;
  onPlaceOrder: (orderData: any) => void;
}

export function ShoppingCart({ cartItems, onUpdateQuantity, onRemoveItem, onPlaceOrder }: ShoppingCartProps) {
  const [customerData, setCustomerData] = useState({
    companyName: "",
    contactPerson: "",
    phone: "",
    email: "",
    address: "",
    inn: "",
    comments: "",
    deliveryType: "pickup"
  });

  const total = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const handleInputChange = (field: string, value: string) => {
    setCustomerData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmitOrder = () => {
    if (!customerData.companyName || !customerData.contactPerson || !customerData.phone) {
      alert("Пожалуйста, заполните обязательные поля");
      return;
    }

    const orderData = {
      items: cartItems,
      customer: customerData,
      total,
      orderDate: new Date().toISOString()
    };

    onPlaceOrder(orderData);
  };

  if (cartItems.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8">
        <Card>
          <CardContent className="text-center py-12">
            <h2 className="mb-4">Корзина пуста</h2>
            <p className="text-muted-foreground mb-6">
              Добавьте товары из каталога для оформления заказа
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="mb-8">Оформление заказа</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Cart Items */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Товары в корзине</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {cartItems.map(item => (
                <div key={item.id} className="flex items-center space-x-4 p-4 border rounded-lg">
                  <div className="w-16 h-16 rounded-lg overflow-hidden bg-muted">
                    <ImageWithFallback
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium">{item.name}</h4>
                    <p className="text-sm text-muted-foreground">
                      {item.price.toLocaleString('ru-RU')} ₽
                    </p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => onUpdateQuantity(item.id, Math.max(1, item.quantity - 1))}
                      className="h-8 w-8"
                    >
                      <Minus className="h-3 w-3" />
                    </Button>
                    <span className="w-8 text-center">{item.quantity}</span>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                      className="h-8 w-8"
                    >
                      <Plus className="h-3 w-3" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => onRemoveItem(item.id)}
                      className="h-8 w-8 text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
            <CardFooter className="border-t pt-6">
              <div className="w-full flex justify-between items-center">
                <span className="text-lg">Итого:</span>
                <span className="text-2xl font-bold">{total.toLocaleString('ru-RU')} ₽</span>
              </div>
            </CardFooter>
          </Card>
        </div>

        {/* Order Form */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Данные заказчика</CardTitle>
              <CardDescription>
                Заполните информацию для оформления заказа
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="companyName">Название организации *</Label>
                <Input
                  id="companyName"
                  value={customerData.companyName}
                  onChange={(e) => handleInputChange("companyName", e.target.value)}
                  placeholder="ООО «Ваша компания»"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="contactPerson">Контактное лицо *</Label>
                <Input
                  id="contactPerson"
                  value={customerData.contactPerson}
                  onChange={(e) => handleInputChange("contactPerson", e.target.value)}
                  placeholder="Иванов Иван Иванович"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="phone">Телефон *</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={customerData.phone}
                    onChange={(e) => handleInputChange("phone", e.target.value)}
                    placeholder="+7 (999) 123-45-67"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={customerData.email}
                    onChange={(e) => handleInputChange("email", e.target.value)}
                    placeholder="email@company.ru"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="inn">ИНН</Label>
                <Input
                  id="inn"
                  value={customerData.inn}
                  onChange={(e) => handleInputChange("inn", e.target.value)}
                  placeholder="1234567890"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="address">Адрес доставки</Label>
                <Textarea
                  id="address"
                  value={customerData.address}
                  onChange={(e) => handleInputChange("address", e.target.value)}
                  placeholder="Укажите полный адрес доставки"
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="deliveryType">Способ получения</Label>
                <Select
                  value={customerData.deliveryType}
                  onValueChange={(value) => handleInputChange("deliveryType", value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pickup">Самовывоз</SelectItem>
                    <SelectItem value="delivery">Доставка</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="comments">Комментарии к заказу</Label>
                <Textarea
                  id="comments"
                  value={customerData.comments}
                  onChange={(e) => handleInputChange("comments", e.target.value)}
                  placeholder="Дополнительные пожелания, сроки поставки..."
                  rows={3}
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSubmitOrder} className="w-full" size="lg">
                Оформить заказ
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}