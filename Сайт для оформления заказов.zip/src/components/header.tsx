import { ShoppingCart, Search, Phone, Mail, User, LogOut } from "lucide-react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "./ui/dropdown-menu";
import { useAuth } from "./auth-context";

interface HeaderProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
  cartItemsCount: number;
  onAuthModalOpen: () => void;
}

export function Header({ activeSection, onSectionChange, cartItemsCount, onAuthModalOpen }: HeaderProps) {
  const { user, logout } = useAuth();

  const handleLogout = () => {
    logout();
    onSectionChange("home");
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center space-x-8">
            <div className="flex items-center space-x-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                <span className="text-sm font-bold">А</span>
              </div>
              <span className="font-semibold">А-Штрих</span>
            </div>
            
            <nav className="hidden md:flex space-x-6">
              <Button
                variant={activeSection === "home" ? "default" : "ghost"}
                onClick={() => onSectionChange("home")}
              >
                Главная
              </Button>
              <Button
                variant={activeSection === "catalog" ? "default" : "ghost"}
                onClick={() => onSectionChange("catalog")}
              >
                Каталог
              </Button>
              <Button
                variant={activeSection === "support" ? "default" : "ghost"}
                onClick={() => onSectionChange("support")}
              >
                Тех. поддержка
              </Button>
            </nav>
          </div>

          <div className="flex items-center space-x-4">
            <div className="hidden lg:flex items-center space-x-4 text-sm text-muted-foreground">
              <div className="flex items-center space-x-1">
                <Phone className="h-4 w-4" />
                <span>+7 (495) 123-45-67</span>
              </div>
              <div className="flex items-center space-x-1">
                <Mail className="h-4 w-4" />
                <span>info@a-shtrih.ru</span>
              </div>
            </div>

            <Button
              variant="outline"
              size="sm"
              onClick={() => onSectionChange("cart")}
              className="relative"
            >
              <ShoppingCart className="h-4 w-4 mr-2" />
              Корзина
              {cartItemsCount > 0 && (
                <Badge
                  variant="destructive"
                  className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs"
                >
                  {cartItemsCount}
                </Badge>
              )}
            </Button>

            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="flex items-center space-x-2">
                    <User className="h-4 w-4" />
                    <span className="hidden md:inline">{user.name}</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <div className="px-2 py-1.5">
                    <p className="text-sm font-medium">{user.name}</p>
                    <p className="text-xs text-muted-foreground">{user.email}</p>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => onSectionChange("profile")}>
                    <User className="mr-2 h-4 w-4" />
                    Личный кабинет
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    Выйти
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button variant="outline" size="sm" onClick={onAuthModalOpen}>
                <User className="h-4 w-4 mr-2" />
                Войти
              </Button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}