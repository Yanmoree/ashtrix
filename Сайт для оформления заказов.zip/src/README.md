# А-Штрих - Сайт кассового оборудования

Полнофункциональный сайт для продажи кассового оборудования и технической поддержки с системой авторизации пользователей.

## Структура проекта

### Frontend (React/TypeScript)
```
/
├── App.tsx                    # Главный компонент приложения
├── components/
│   ├── auth-context.tsx       # Контекст авторизации
│   ├── auth-modal.tsx         # Модальное окно входа/регистрации
│   ├── user-profile.tsx       # Личный кабинет пользователя
│   ├── header.tsx             # Заголовок с навигацией
│   ├── home-page.tsx          # Главная страница
│   ├── product-catalog.tsx    # Каталог товаров
│   ├── shopping-cart.tsx      # Корзина покупок
│   ├── tech-support.tsx       # Техническая поддержка
│   └── ui/                    # Компоненты пользовательского интерфейса
└── styles/globals.css         # Глобальные стили
```

### Backend (PHP)
```
/
├── auth_config.php           # Конфигурация авторизации
├── auth_register.php         # Регистрация пользователей
├── auth_login.php            # Вход пользователей
├── auth_logout.php           # Выход пользователей
├── auth_check.php            # Проверка статуса авторизации
├── auth_update_profile.php   # Обновление профиля
├── user_orders.php           # Заказы пользователя
├── user_support_tickets.php  # Заявки пользователя
├── process_order.php         # Обработка заказов
├── process_support.php       # Обработка заявок техподдержки
└── admin.php                 # Административная панель
```

### Legacy HTML версия
```
/
├── index.html               # Главная страница (HTML)
├── catalog.html             # Каталог товаров (HTML)
├── cart.html                # Корзина (HTML)
├── support.html             # Техподдержка (HTML)
├── style.css                # Стили (CSS)
└── script.js                # JavaScript функциональность
```

## Возможности

### Система авторизации:
- **Регистрация пользователей** с валидацией данных
- **Вход/выход** из системы с сессиями
- **Личный кабинет** с историей заказов и обращений
- **Редактирование профиля** пользователя
- **Автоматическое заполнение** форм для авторизованных пользователей

### Для клиентов:
- **Главная страница** с информацией о компании и услугах
- **Каталог товаров** с фильтрацией и поиском
- **Корзина** с возможностью оформления заказа
- **Техническая поддержка** с формой отправки заявок
- **История заказов** и обращений в личном кабинете
- **Адаптивный дизайн** для всех устройств

### Для администраторов:
- **Админ панель** для просмотра заказов и заявок
- **Статистика** по заказам и обращениям
- **Система уведомлений** по email
- **Логирование** всех операций

## Установка и настройка

### 1. Требования
- Веб-сервер (Apache/Nginx)
- PHP 7.4+
- Права на запись в директории проекта
- Node.js и npm (для React версии)

### 2. Установка React версии
1. Скачайте все файлы проекта
2. Установите зависимости:
   ```bash
   npm install
   ```
3. Запустите проект:
   ```bash
   npm run dev
   ```

### 3. Настройка PHP backend
1. Разместите PHP файлы в корневой директории веб-сервера
2. Настройте права доступа на запись для директорий:
   ```bash
   chmod 755 /path/to/project
   chmod 777 /path/to/project/users
   chmod 777 /path/to/project/sessions
   chmod 777 /path/to/project/orders
   chmod 777 /path/to/project/support_tickets
   ```

### 4. Настройка PHP
В файлах `process_order.php` и `process_support.php`:
- Раскомментируйте строки с `mail()` для отправки email уведомлений
- Настройте SMTP параметры при необходимости
- Измените email адреса получателей

### 5. Настройка админ панели
В файле `admin.php`:
- Измените пароль в переменной `$admin_password` (по умолчанию: `admin123`)
- Для продакшена рекомендуется использовать более безопасную авторизацию

## Использование

### Для клиентов:
1. Откройте приложение в браузере
2. Зарегистрируйтесь или войдите в систему
3. Перейдите в каталог для просмотра товаров
4. Добавляйте товары в корзину
5. Оформите заказ (данные заполнятся автоматически если вы авторизованы)
6. Просматривайте историю заказов в личном кабинете
7. При необходимости создайте заявку в техподдержку

### Для администраторов:
1. Откройте `admin.php` в браузере
2. Введите пароль для входа
3. Просматривайте заказы и заявки
4. Отслеживайте статистику

## API Endpoints

### Авторизация:
- `POST /auth_register.php` - Регистрация пользователя
- `POST /auth_login.php` - Вход в систему
- `POST /auth_logout.php` - Выход из системы
- `GET /auth_check.php` - Проверка статуса авторизации
- `POST /auth_update_profile.php` - Обновление профиля

### Пользовательские данные:
- `GET /user_orders.php` - Получение заказов пользователя
- `GET /user_support_tickets.php` - Получение заявок пользователя

### Обработка заказов:
- `POST /process_order.php` - Создание заказа
- `POST /process_support.php` - Создание заявки в техподдержку

## Структура данных

### Пользователь:
```json
{
  "id": "user_123456",
  "email": "user@example.com",
  "name": "Иван Иванов",
  "company": "ООО Пример",
  "phone": "+7 (999) 123-45-67",
  "role": "user",
  "registration_date": "2025-01-20 10:30:00"
}
```

### Заказы сохраняются в JSON формате:
```json
{
  "order_id": "ORD-2025-123456",
  "user_id": "user_123456",
  "company_name": "ООО Пример",
  "contact_person": "Иван Иванов",
  "phone": "+7 (999) 123-45-67",
  "cart": [...],
  "total": 50000,
  "order_date": "2025-01-20 10:30:00",
  "status": "new"
}
```

### Заявки техподдержки:
```json
{
  "ticket_id": "SUP-2025-123456",
  "user_id": "user_123456",
  "name": "Иван Иванов",
  "phone": "+7 (999) 123-45-67",
  "category": "hardware",
  "urgency": "high",
  "description": "Описание проблемы",
  "created_date": "2025-01-20 10:30:00",
  "status": "new"
}
```

## Функциональность авторизации

### Безопасность:
- Хеширование паролей с помощью `password_hash()`
- Защищенные сессии с HTTP-only cookies
- Валидация данных на сервере
- Логирование всех операций авторизации

### Файловая система (временное решение):
- Пользователи сохраняются в директории `/users/`
- Сессии в директории `/sessions/`
- Двойная индексация по ID и email для быстрого поиска

### Миграция на БД:
Проект готов для подключения к базе данных:
1. Обновите `auth_config.php` с параметрами БД
2. Создайте таблицы для пользователей, заказов и заявок
3. Замените файловые функции на SQL запросы

## Функциональность JavaScript

### Управление корзиной:
- `addToCart(productId)` - добавление товара
- `updateQuantity(productId, quantity)` - изменение количества
- `removeFromCart(productId)` - удаление товара
- `getCartTotal()` - подсчет суммы

### Авторизация:
- Контекст React для управления состоянием пользователя
- Автоматическая проверка авторизации при загрузке
- Сохранение сессии между перезагрузками

### Фильтрация товаров:
- Поиск по названию и описанию
- Фильтрация по категориям
- Динамическое обновление результатов

### Уведомления:
- Toast уведомления при добавлении в корзину
- Модальные окна для подтверждений
- Валидация форм

## Безопасность

### Реализованные меры:
- Валидация данных на сервере
- Защита от XSS атак
- Хеширование паролей
- Защищенные сессии
- Логирование операций

### Рекомендации для продакшена:
- Используйте HTTPS
- Настройте более сложную авторизацию
- Добавьте CSRF защиту
- Используйте базу данных вместо файлов
- Настройте резервное копирование
- Ограничьте количество попыток входа

## Миграция на базу данных

### Предлагаемая структура таблиц:

```sql
-- Пользователи
CREATE TABLE users (
    id VARCHAR(50) PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    company VARCHAR(255),
    phone VARCHAR(50),
    role ENUM('user', 'admin') DEFAULT 'user',
    registration_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Заказы
CREATE TABLE orders (
    id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50),
    company_name VARCHAR(255) NOT NULL,
    contact_person VARCHAR(255) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    email VARCHAR(255),
    inn VARCHAR(50),
    address TEXT,
    delivery_type ENUM('pickup', 'delivery') DEFAULT 'pickup',
    comments TEXT,
    cart_data JSON NOT NULL,
    total DECIMAL(10,2) NOT NULL,
    order_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    status ENUM('new', 'in_progress', 'completed', 'cancelled') DEFAULT 'new',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Заявки техподдержки
CREATE TABLE support_tickets (
    id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50),
    name VARCHAR(255) NOT NULL,
    company VARCHAR(255),
    phone VARCHAR(50) NOT NULL,
    email VARCHAR(255),
    category VARCHAR(50),
    urgency ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    equipment VARCHAR(255),
    description TEXT NOT NULL,
    created_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    status ENUM('new', 'in_progress', 'resolved', 'closed') DEFAULT 'new',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Сессии
CREATE TABLE user_sessions (
    session_id VARCHAR(128) PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
```

## Интеграции

### Email уведомления:
Для корректной работы email уведомлений настройте:
- SMTP сервер
- SPF/DKIM записи
- Обработку bounce сообщений

### SMS уведомления:
Для критических заявок можно добавить SMS уведомления через:
- Twilio
- SMS.ru
- SMSC.ru

## Техподдержка

При возникновении проблем:
1. Проверьте права доступа к файлам
2. Убедитесь, что PHP работает корректно
3. Проверьте логи веб-сервера
4. Просмотрите файлы `orders.log`, `support.log` и `auth.log`

## Лицензия

Проект создан для демонстрационных целей. Используйте по своему усмотрению.

## Авторы

Создано с помощью AI ассистента для компании "А-Штрих".