<?php
require_once 'auth_config.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

try {
    // Check if user is authenticated
    $currentUser = getCurrentUser();
    
    if (!$currentUser) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Not authenticated']);
        exit;
    }

    // Get user's support tickets
    $tickets = getUserSupportTickets($currentUser['id']);
    
    // Format tickets for frontend
    $formattedTickets = [];
    foreach ($tickets as $ticket) {
        $formattedTickets[] = [
            'id' => $ticket['ticket_id'],
            'subject' => $ticket['description'] ? substr($ticket['description'], 0, 50) . '...' : 'Обращение в поддержку',
            'status' => $ticket['status'],
            'createdDate' => $ticket['created_date'],
            'category' => $ticket['category'] ?? 'general',
            'urgency' => $ticket['urgency'] ?? 'medium'
        ];
    }

    echo json_encode([
        'success' => true,
        'tickets' => $formattedTickets
    ]);

} catch (Exception $e) {
    error_log('User support tickets error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Internal server error']);
}
?>