<?php
require_once 'auth_config.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

try {
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode(['success' => false, 'error' => 'Invalid JSON data']);
        exit;
    }

    // Extract and sanitize data
    $email = sanitizeInput($input['email'] ?? '');
    $password = $input['password'] ?? '';
    $name = sanitizeInput($input['name'] ?? '');
    $company = sanitizeInput($input['company'] ?? '');
    $phone = sanitizeInput($input['phone'] ?? '');

    // Validation
    if (empty($email) || empty($password) || empty($name)) {
        echo json_encode(['success' => false, 'error' => 'Заполните все обязательные поля']);
        exit;
    }

    if (!validateEmail($email)) {
        echo json_encode(['success' => false, 'error' => 'Некорректный email адрес']);
        exit;
    }

    if (strlen($password) < 6) {
        echo json_encode(['success' => false, 'error' => 'Пароль должен содержать минимум 6 символов']);
        exit;
    }

    // Check if user already exists
    if (getUserByEmail($email)) {
        echo json_encode(['success' => false, 'error' => 'Пользователь с таким email уже существует']);
        exit;
    }

    // Create new user
    $user = createUser($email, $password, $name, $company, $phone);
    
    if (!$user) {
        echo json_encode(['success' => false, 'error' => 'Ошибка создания пользователя']);
        exit;
    }

    // Login the user
    loginUser($user);

    // Log activity
    logActivity('User registered', $email);

    // Return user data (without password hash)
    $userData = [
        'id' => $user['id'],
        'email' => $user['email'],
        'name' => $user['name'],
        'company' => $user['company'],
        'phone' => $user['phone'],
        'role' => $user['role'],
        'registrationDate' => $user['registration_date']
    ];

    echo json_encode([
        'success' => true,
        'user' => $userData,
        'message' => 'Регистрация прошла успешно'
    ]);

} catch (Exception $e) {
    error_log('Registration error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Внутренняя ошибка сервера']);
}
?>