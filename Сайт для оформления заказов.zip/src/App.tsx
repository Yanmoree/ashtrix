import { useState } from "react";
import { Header } from "./components/header";
import { HomePage } from "./components/home-page";
import { ProductCatalog } from "./components/product-catalog";
import { ShoppingCart } from "./components/shopping-cart";
import { TechSupport } from "./components/tech-support";
import { UserProfile } from "./components/user-profile";
import { AuthModal } from "./components/auth-modal";
import { AuthProvider } from "./components/auth-context";
import { toast } from "sonner@2.0.3";

interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  description: string;
  features: string[];
  inStock: boolean;
  image: string;
}

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
}

export default function App() {
  const [activeSection, setActiveSection] = useState("home");
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  const handleAddToCart = (product: Product) => {
    setCartItems(prev => {
      const existingItem = prev.find(item => item.id === product.id);
      if (existingItem) {
        return prev.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        return [...prev, {
          id: product.id,
          name: product.name,
          price: product.price,
          quantity: 1,
          image: product.image
        }];
      }
    });
    toast.success(`${product.name} добавлен в корзину`);
  };

  const handleUpdateQuantity = (id: string, quantity: number) => {
    setCartItems(prev =>
      prev.map(item =>
        item.id === id ? { ...item, quantity } : item
      )
    );
  };

  const handleRemoveItem = (id: string) => {
    setCartItems(prev => prev.filter(item => item.id !== id));
    toast.success("Товар удален из корзины");
  };

  const handlePlaceOrder = (orderData: any) => {
    // Here we would normally send the order to backend
    console.log("Order placed:", orderData);
    
    // Clear cart and show success message
    setCartItems([]);
    setActiveSection("catalog");
    toast.success("Заказ успешно оформлен! Мы свяжемся с вами в ближайшее время.");
  };

  const renderContent = () => {
    switch (activeSection) {
      case "home":
        return <HomePage onNavigateToSection={setActiveSection} />;
      case "catalog":
        return <ProductCatalog onAddToCart={handleAddToCart} />;
      case "cart":
        return (
          <ShoppingCart
            cartItems={cartItems}
            onUpdateQuantity={handleUpdateQuantity}
            onRemoveItem={handleRemoveItem}
            onPlaceOrder={handlePlaceOrder}
          />
        );
      case "support":
        return <TechSupport />;
      case "profile":
        return <UserProfile />;
      default:
        return <HomePage onNavigateToSection={setActiveSection} />;
    }
  };

  return (
    <AuthProvider>
      <div className="min-h-screen bg-background">
        <Header
          activeSection={activeSection}
          onSectionChange={setActiveSection}
          cartItemsCount={cartItems.reduce((sum, item) => sum + item.quantity, 0)}
          onAuthModalOpen={() => setIsAuthModalOpen(true)}
        />
        {renderContent()}
        
        <AuthModal
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
        />
      </div>
    </AuthProvider>
  );
}