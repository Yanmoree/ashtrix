<?php
require_once 'auth_config.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Проверяем метод запроса
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

try {
    // Check if user is authenticated
    $currentUser = getCurrentUser();
    
    // Получаем данные из формы
    $name = trim($_POST['name'] ?? '');
    $company = trim($_POST['company'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $urgency = trim($_POST['urgency'] ?? 'medium');
    $equipment = trim($_POST['equipment'] ?? '');
    $description = trim($_POST['description'] ?? '');

    // If user is authenticated, pre-fill some data
    if ($currentUser) {
        if (empty($name)) {
            $name = $currentUser['name'];
        }
        if (empty($email)) {
            $email = $currentUser['email'];
        }
        if (empty($company) && !empty($currentUser['company'])) {
            $company = $currentUser['company'];
        }
        if (empty($phone) && !empty($currentUser['phone'])) {
            $phone = $currentUser['phone'];
        }
    }

    // Валидация обязательных полей
    if (empty($name) || empty($phone) || empty($description)) {
        echo json_encode(['success' => false, 'error' => 'Required fields missing']);
        exit;
    }

    // Валидация телефона
    if (!preg_match('/^\+?[0-9\s\-\(\)]{10,}$/', $phone)) {
        echo json_encode(['success' => false, 'error' => 'Invalid phone number']);
        exit;
    }

    // Валидация email если указан
    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'error' => 'Invalid email address']);
        exit;
    }

    // Создаем уникальный ID заявки
    $ticketId = 'SUP-' . date('Y') . '-' . sprintf('%06d', rand(1, 999999));
    
    // Подготавливаем данные заявки
    $supportData = [
        'ticket_id' => $ticketId,
        'user_id' => $currentUser ? $currentUser['id'] : null, // Link to user if authenticated
        'name' => $name,
        'company' => $company,
        'phone' => $phone,
        'email' => $email,
        'category' => $category,
        'urgency' => $urgency,
        'equipment' => $equipment,
        'description' => $description,
        'created_date' => date('Y-m-d H:i:s'),
        'status' => 'new'
    ];

    // Сохраняем заявку в файл (в реальном проекте используйте базу данных)
    $supportDir = 'support_tickets';
    if (!is_dir($supportDir)) {
        mkdir($supportDir, 0755, true);
    }
    
    $ticketFile = $supportDir . '/' . $ticketId . '.json';
    if (file_put_contents($ticketFile, json_encode($supportData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) === false) {
        echo json_encode(['success' => false, 'error' => 'Failed to save support ticket']);
        exit;
    }

    // Определяем приоритет для уведомления
    $urgencyLabels = [
        'low' => 'Низкая',
        'medium' => 'Средняя',
        'high' => 'Высокая',
        'critical' => 'Критическая'
    ];

    $categoryLabels = [
        'hardware' => 'Аппаратная проблема',
        'software' => 'Программная проблема',
        'fiscal' => 'Фискальные вопросы',
        'setup' => 'Настройка и установка',
        'training' => 'Обучение персонала',
        'other' => 'Другое'
    ];

    // Отправляем email уведомление
    $subject = 'Новая заявка в техподдержку № ' . $ticketId . ' - А-Штрих';
    $message = "Получена новая заявка в техподдержку:\n\n";
    $message .= "Номер заявки: " . $ticketId . "\n";
    $message .= "Имя: " . $name . "\n";
    $message .= "Организация: " . ($company ?: 'Не указана') . "\n";
    $message .= "Телефон: " . $phone . "\n";
    $message .= "Email: " . ($email ?: 'Не указан') . "\n";
    $message .= "Категория: " . ($categoryLabels[$category] ?? 'Не указана') . "\n";
    $message .= "Срочность: " . ($urgencyLabels[$urgency] ?? 'Средняя') . "\n";
    $message .= "Оборудование: " . ($equipment ?: 'Не указано') . "\n\n";
    $message .= "Описание проблемы:\n" . $description . "\n\n";
    $message .= "Дата создания: " . date('d.m.Y H:i');

    $headers = "From: noreply@a-shtrih.ru\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

    // Определяем приоритет email в зависимости от срочности
    if ($urgency === 'critical') {
        $headers .= "X-Priority: 1\r\n";
        $headers .= "X-MSMail-Priority: High\r\n";
    } elseif ($urgency === 'high') {
        $headers .= "X-Priority: 2\r\n";
        $headers .= "X-MSMail-Priority: High\r\n";
    }

    // Раскомментируйте строку ниже для отправки email
    // mail('support@a-shtrih.ru', $subject, $message, $headers);

    // Отправляем SMS для критических заявок (интеграция с SMS-сервисом)
    if ($urgency === 'critical') {
        // Здесь можно добавить отправку SMS
        // sendSMS('+79991234567', 'КРИТИЧЕСКАЯ заявка №' . $ticketId . ' от ' . $name);
    }

    // Логируем заявку
    $logEntry = date('Y-m-d H:i:s') . " - New support ticket: " . $ticketId . " from " . $name . " (" . $phone . ") - " . $urgency . "\n";
    file_put_contents('support.log', $logEntry, FILE_APPEND | LOCK_EX);

    // Возвращаем успешный ответ
    echo json_encode([
        'success' => true,
        'ticket_id' => $ticketId,
        'message' => 'Support ticket created successfully'
    ]);

} catch (Exception $e) {
    error_log('Support ticket processing error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Internal server error']);
}
?>